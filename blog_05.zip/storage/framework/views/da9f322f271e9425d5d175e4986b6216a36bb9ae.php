<?php $__env->startSection('titulo', 'Ficha de post'); ?>

<?php $__env->startSection('contenido'); ?>

    <div class="container">

        <form method="POST" action="#" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="card" >
                <div class="card-body">
                    <h2 class="card-title"><?php echo e($posts->titulo); ?></h2>
                    <h6 class="card-subtitle mb-2 text-muted">Escrito por <?php echo e($posts->usuario->login); ?> el <?php echo e(Carbon\Carbon::parse($posts->created_at)->format('d/m/Y')); ?></h6>
                    <p class="card-text"><?php echo e($posts->contenido); ?></p>

                    <div>
                        <h3>Comentarios</h3>

                        <?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-header">
                                <blockquote class="blockquote mb-0">
                                <p><?php echo e($comentario->contenido); ?></p>

                                    <footer class="blockquote-footer">Usuario: <?php echo e($comentario->usuario->login); ?></cite></footer>
                                </blockquote>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="col-md-12">
                        <div class="form-group label-floating">
                            <br>
                            <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-danger">Atrás</a>
                        </div>
                    </div>
                </div>

            </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Posts-main/resources/views/posts/show.blade.php ENDPATH**/ ?>