<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(asset(mix('css/app.css'))); ?>" rel="stylesheet">
    <script src="<?php echo e(asset(mix('js/app.js'))); ?>"></script>
    <title> <?php echo $__env->yieldContent('titulo'); ?> </title>

</head>
<body>

    <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card-body d-flex justify-content-between align-items-right">
        <p><p>
        <p><?php echo e(fechaActual('2023/01/17')); ?></p>
    </div>

    <?php echo $__env->yieldContent('contenido'); ?>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Posts-main/resources/views/plantilla.blade.php ENDPATH**/ ?>