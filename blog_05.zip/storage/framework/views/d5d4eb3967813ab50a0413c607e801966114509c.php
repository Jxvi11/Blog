<?php $__env->startSection('titulo', 'Listado de posts'); ?>

<?php $__env->startSection('contenido'); ?>

    <div class="container">
        <div class="row">
            <legend>Listado de posts</legend>
            <table class="table table-striped table-hover ">
              <thead>
                <tr>
                    <th>ID</th>
                    <th>Titulo</th>
                    <th>Ver</th>
                    <th>Eliminar</th>
                    <th>Editar</th>

                </tr>
              </thead>
              <tbody>
                <?php if(count($posts) > 0 ): ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($p->id); ?></td>
                            <td><?php echo e($p->titulo); ?> (<?php echo e($p->usuario->login); ?>)</td>
                            <td>
                                <a href="<?php echo e(route('posts.show',$p->id)); ?>" method="GET" class="btn btn-success btn-sm">Ver</a>
                            </td>
                            <td>
                                <form id="delete-form-<?php echo e($p->id); ?>" action="<?php echo e(route('posts.destroy',$p->id)); ?>" style="display: none;" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                                <button type="button" class="btn btn-danger btn-sm" onclick="if(confirm('¿Seguro que quieres eliminar el siguiente posts?')){
                                    event.preventDefault();
                                    document.getElementById('delete-form-<?php echo e($p->id); ?>').submit();
                                }else {
                                    event.preventDefault();
                                }">Eliminar
                                </form>
                            </td>
                            <td>
                                <a href="<?php echo e(route('posts.edit',$p->id)); ?>" m method="GET" class="btn btn-info btn-sm">Editar</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php echo e($posts->links()); ?>


                <?php endif; ?>
              </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Posts-main/resources/views/posts/index.blade.php ENDPATH**/ ?>